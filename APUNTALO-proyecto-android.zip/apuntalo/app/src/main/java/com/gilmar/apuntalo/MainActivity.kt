package com.gilmar.apuntalo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val ComponentActivity.dataStore by preferencesDataStore(name = "apuntalo")
private val BG = Color(0xFF17191F)
private val CARD = Color(0xFF252932)
private val ACCENT = Color(0xFF65B9A5)
private val MUTED = Color(0xFF9AA3B2)

data class TaskItem(val id: Long, val title: String, val done: Boolean = false, val category: String = "Personal")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ApuntaloApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApuntaloApp(activity: MainActivity) {
    val scope = rememberCoroutineScope()
    val key = stringPreferencesKey("tasks")
    val tasks by activity.dataStore.data.map { prefs -> decodeTasks(prefs[key] ?: "[]") }.collectAsState(initial = emptyList())
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var newTask by remember { mutableStateOf("") }
    var income by remember { mutableStateOf("4700") }
    var expense by remember { mutableStateOf("") }
    var expenses by remember { mutableStateOf(listOf<Pair<String, Double>>()) }
    fun save(list: List<TaskItem>) { scope.launch { activity.dataStore.edit { it[key] = encodeTasks(list) } } }

    MaterialTheme(colorScheme = darkColorScheme(background = BG, surface = CARD, primary = ACCENT, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = BG, bottomBar = {
            NavigationBar(containerColor = CARD, contentColor = Color.White) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Lista") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("Calendario") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Payments, null) }, label = { Text("Finanzas") })
            }
        }, floatingActionButton = { if (tab == 0) FloatingActionButton(onClick = { showAdd = true }, containerColor = ACCENT, contentColor = BG) { Icon(Icons.Default.Add, "Añadir tarea") } }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(24.dp))
                Text("APÚNTALO", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 1.5.sp)
                Text("que se te olvida", color = ACCENT, fontSize = 13.sp)
                Text("Creada por Gilmar", color = MUTED, fontSize = 10.sp)
                Spacer(Modifier.height(26.dp))
                when (tab) {
                    0 -> {
                        Text("Mi lista", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text("${tasks.count { !it.done }} pendientes · ${tasks.count { it.done }} completadas", color = MUTED, fontSize = 13.sp)
                        Spacer(Modifier.height(16.dp))
                        if (tasks.isEmpty()) EmptyState("Tu lista está despejada", "Pulsa + para apuntar lo que no quieres olvidar.")
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
                            items(tasks, key = { it.id }) { task ->
                                Row(Modifier.fillMaxWidth().background(CARD, RoundedCornerShape(16.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Surface(onClick = { save(tasks.map { if (it.id == task.id) it.copy(done = !it.done) else it }) }, shape = CircleShape, color = if (task.done) ACCENT else Color.Transparent, border = if (task.done) null else androidx.compose.foundation.BorderStroke(1.dp, MUTED), modifier = Modifier.size(26.dp)) { Box(contentAlignment = Alignment.Center) { if (task.done) Icon(Icons.Default.Check, null, tint = BG, modifier = Modifier.size(17.dp)) } }
                                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                        Text(task.title, color = if (task.done) MUTED else Color.White, textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None, fontWeight = FontWeight.Medium)
                                        Text(task.category, color = ACCENT, fontSize = 11.sp)
                                    }
                                    IconButton(onClick = { save(tasks.filterNot { it.id == task.id }) }) { Icon(Icons.Default.Delete, "Eliminar", tint = MUTED) }
                                }
                            }
                        }
                    }
                    1 -> {
                        Text("Calendario", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(16.dp))
                        EmptyState("Tu calendario", "Esta primera versión deja preparada la sección. La sincronización con Google y Samsung Calendar se añadirá en una actualización.")
                    }
                    else -> {
                        Text("Finanzas", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(14.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = CARD)) { Column(Modifier.padding(18.dp)) {
                            Text("Ingreso mensual", color = MUTED)
                            OutlinedTextField(value = income, onValueChange = { income = it }, label = { Text("Ingreso ($)") }, singleLine = true)
                            Spacer(Modifier.height(10.dp))
                            Text("Balance estimado", color = MUTED)
                            Text("$${((income.toDoubleOrNull() ?: 0.0) - expenses.sumOf { it.second }).let { String.format("%.2f", it) }}", color = ACCENT, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        } }
                        Spacer(Modifier.height(14.dp))
                        Text("Añadir gasto", fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(value = expense, onValueChange = { expense = it }, modifier = Modifier.weight(1f), label = { Text("Cantidad ($)") }, singleLine = true)
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = { val amount = expense.toDoubleOrNull(); if (amount != null && amount > 0) { expenses = expenses + ("Gasto" to amount); expense = "" } }, colors = ButtonDefaults.buttonColors(containerColor = ACCENT, contentColor = BG)) { Text("Añadir") }
                        }
                        expenses.forEach { Text("Gasto     -$${String.format("%.2f", it.second)}", Modifier.fillMaxWidth().padding(vertical = 8.dp), color = Color.White) }
                        Text("Los movimientos de esta versión inicial viven en memoria; el guardado permanente de finanzas se añadirá en la siguiente iteración.", color = MUTED, fontSize = 11.sp)
                    }
                }
            }
            if (showAdd) AlertDialog(onDismissRequest = { showAdd = false }, title = { Text("Nueva tarea") }, text = { OutlinedTextField(value = newTask, onValueChange = { newTask = it }, label = { Text("¿Qué no quieres olvidar?") }, singleLine = true) }, confirmButton = { TextButton(onClick = { if (newTask.isNotBlank()) { save(tasks + TaskItem(System.currentTimeMillis(), newTask.trim())); newTask = ""; showAdd = false } }) { Text("Guardar") } }, dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancelar") } })
        }
    }
}

@Composable fun EmptyState(title: String, body: String) {
    Column(Modifier.fillMaxWidth().padding(top = 44.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(62.dp).background(CARD, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Check, null, tint = ACCENT, modifier = Modifier.size(30.dp)) }
        Spacer(Modifier.height(14.dp)); Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp); Spacer(Modifier.height(6.dp)); Text(body, color = MUTED, fontSize = 13.sp)
    }
}
private fun encodeTasks(tasks: List<TaskItem>): String = JSONArray().apply { tasks.forEach { put(JSONObject().put("id", it.id).put("title", it.title).put("done", it.done).put("category", it.category)) } }.toString()
private fun decodeTasks(raw: String): List<TaskItem> = try { val arr = JSONArray(raw); (0 until arr.length()).map { val o = arr.getJSONObject(it); TaskItem(o.getLong("id"), o.getString("title"), o.optBoolean("done"), o.optString("category", "Personal")) } } catch (_: Exception) { emptyList() }
