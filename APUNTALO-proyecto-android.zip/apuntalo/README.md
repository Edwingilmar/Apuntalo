# APÚNTALO

Proyecto Android inicial en Kotlin + Jetpack Compose. Esta es una primera versión funcional de la lista con guardado local de tareas, y una base inicial para Calendario y Finanzas.

## Crear APK en GitHub Actions
1. Crea un repositorio nuevo en GitHub llamado `apuntalo`.
2. Sube el contenido de esta carpeta a la raíz del repositorio (no la carpeta contenedora adicional).
3. Abre la pestaña **Actions** y ejecuta **Build APÚNTALO APK** con **Run workflow**. También compila automáticamente al hacer push a `main`.
4. Cuando termine, abre la ejecución y descarga el artifact **APUNTALO-debug-apk**. Dentro está `app-debug.apk`.

## Estado honesto
Esta primera entrega no implementa todavía alarmas/notificaciones, sincronización de calendarios, calendario escolar, temas seleccionables, wallpapers ni persistencia de Finanzas. La lista sí guarda tareas localmente en el dispositivo.
